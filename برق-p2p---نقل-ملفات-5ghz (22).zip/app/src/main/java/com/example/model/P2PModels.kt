package com.example.model

import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.graphics.ImageBitmap
import java.io.File
import java.util.Locale

enum class MediaViewMode(val arabicLabel: String) {
    LIST("قائمة تفصيلية"),
    GRID("شبكة مصغرات")
}

enum class SafUriStatus(val arabicLabel: String) {
    VALID("صلاحية نشطة وصالحة"),
    PERMISSION_REVOKED("تم إلغاء صلاحية الوصول للمجلد"),
    FOLDER_DELETED_OR_UNREADABLE("المجلد محذوف أو غير قابل للقراءة"),
    INVALID_URI("رابط المجلد غير صالح")
}

@Immutable
data class SafValidationResult(
    val uri: Uri,
    val status: SafUriStatus,
    val displayName: String = "",
    val documentId: String = "",
    val message: String = status.arabicLabel
) {
    val isValid: Boolean
        get() = status == SafUriStatus.VALID
}

enum class FileCategory(
    val arabicLabel: String,
    val badgeColorHex: Long
) {
    VIDEO("فيديو", 0xFFF43F5E),
    IMAGE("صورة", 0xFF00E5FF),
    AUDIO("صوتيات وموسيقى", 0xFFEC4899),
    GAME_APK("تطبيق APK", 0xFF10B981),
    ARCHIVE("ملف مضغوط", 0xFFF59E0B),
    DOCUMENT("مستند / ملف", 0xFF8B5CF6),
    FOLDER("مجلد فرعي", 0xFF06B6D4);

    companion object {
        val VIDEO_EXTENSIONS = setOf(
            "mp4", "mkv", "mov", "avi", "webm", "3gp", "flv", "m4v", "ts", "mts", "m2ts",
            "mpeg", "mpg", "vob", "ogv", "wmv", "asf", "divx", "f4v", "rmvb"
        )
        val IMAGE_EXTENSIONS = setOf(
            "jpg", "jpeg", "png", "webp", "heic", "heif", "gif", "bmp", "avif", "dng", "raw"
        )
        val AUDIO_EXTENSIONS = setOf(
            "mp3", "wav", "m4a", "aac", "flac", "ogg", "opus", "amr", "wma", "mid"
        )

        fun fromFileName(name: String, mimeType: String? = null, isDirectory: Boolean = false): FileCategory {
            if (isDirectory) return FOLDER
            val cleanName = name.substringAfterLast('/')
            val ext = cleanName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            val lower = cleanName.lowercase(Locale.ROOT)
            val mime = mimeType?.lowercase(Locale.ROOT) ?: ""
            return when {
                lower.endsWith(".apk") || lower.endsWith(".xapk") || lower.endsWith(".apks") ||
                    lower.endsWith(".obb") || mime == "application/vnd.android.package-archive" -> GAME_APK
                ext in VIDEO_EXTENSIONS || mime.startsWith("video/") -> VIDEO
                ext in IMAGE_EXTENSIONS || mime.startsWith("image/") -> IMAGE
                ext in AUDIO_EXTENSIONS || mime.startsWith("audio/") -> AUDIO
                lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z") ||
                    lower.endsWith(".tar") || lower.endsWith(".gz") || lower.endsWith(".bz2") ||
                    mime.contains("zip") || mime.contains("rar") || mime.contains("compressed") -> ARCHIVE
                else -> DOCUMENT
            }
        }
    }
}

enum class TransferDirection(val arabicTitle: String) {
    SENDING("إرسال مباشر (P2P)"),
    RECEIVING("استلام وتحميل (P2P)")
}

enum class FileTransferStatus(val arabicLabel: String) {
    QUEUED("في قائمة الانتظار"),
    WAITING("في الانتظار"),
    TRANSFERRING("جاري النقل بالدفعات"),
    PAUSED("متوقف مؤقتاً"),
    RETRYING("جاري إعادة المحاولة..."),
    VERIFYING("جاري التحقق من سلامة الملف (SHA-256)"),
    COMPLETED("مكتمل وتم التحقق (SHA-256)"),
    FAILED("فشل النقل"),
    CANCELLED("تم الإلغاء");

    val isWaitingOrQueued: Boolean
        get() = this == QUEUED || this == WAITING
}

enum class ChunkSizeOption(val bytes: Int, val label: String, val description: String) {
    AUTO_MAX(8 * 1024 * 1024, "أقصى سرعة تلقائية (Auto Max)", "تدفق مباشر متوازي بأقصى سرعة تسمح بها الشبكة والأجهزة بدون سقف"),
    CHUNK_64KB(64 * 1024, "64 KB (للشبكات الضعيفة)", "مناسب لـ 3G والشبكات البطيئة"),
    CHUNK_256KB(256 * 1024, "256 KB (متوازن)", "مناسب لـ 4G و Wi-Fi 2.4GHz"),
    CHUNK_512KB(512 * 1024, "512 KB (سريع)", "ممتاز للوسائط والمستندات"),
    CHUNK_1MB(1024 * 1024, "1 MB (موصى به)", "أداء عالٍ لشبكات Wi-Fi ونقاط الاتصال"),
    CHUNK_2MB(2 * 1024 * 1024, "2 MB (توربو)", "للملفات الضخمة والشبكات السريعة"),
    CHUNK_4MB(4 * 1024 * 1024, "4 MB (فائق السرعة)", "أقصى تدفق للملفات الكبيرة عبر Keep-Alive");

    val bytesLong: Long
        get() = bytes.toLong().coerceAtLeast(1L)
}

/**
 * Computes the total number of chunks for a 64-bit [sizeBytes] file using pure `Long` arithmetic
 * so files larger than 4 GB (up to multi-terabyte theoretical limits) never overflow `Int`.
 */
fun computeTotalChunksForSize(sizeBytes: Long, chunkSizeBytes: Int): Int {
    val safeChunk = chunkSizeBytes.toLong().coerceAtLeast(1L)
    val safeSize = sizeBytes.coerceAtLeast(0L)
    if (safeSize == 0L) return 1
    return ((safeSize + safeChunk - 1L) / safeChunk).coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()
}

enum class SortOption(val arabicLabel: String) {
    DATE_DESC("التاريخ (الأحدث أولاً)"),
    DATE_ASC("التاريخ (الأقدم أولاً)"),
    NAME_ASC("الاسم (أ - ي)"),
    NAME_DESC("الاسم (ي - أ)"),
    SIZE_DESC("الحجم (الأكبر أولاً)"),
    SIZE_ASC("الحجم (الأصغر أولاً)"),
    TYPE_ASC("النوع (الفئة والامتداد)")
}

enum class FilesSubTab(val arabicLabel: String) {
    ALL("الكل (مجلدات وملفات)"),
    DOWNLOADS("التنزيلات والمجلدات"),
    FOLDERS("المجلدات فقط"),
    RECENT("الحديثة"),
    DOCUMENTS("مستندات و PDF"),
    ARCHIVES("مضغوطة ZIP/RAR"),
    APKS("ملفات APK و OBB")
}

enum class SenderSessionPhase(val arabicLabel: String) {
    IDLE("جاهز لبدء جلسة الإرسال"),
    PREPARING_FILES("جاري تجهيز الملفات وحساب SHA-256..."),
    AWAITING_RECEIVER("جلسة إرسال نشطة — بانتظار اتصال المستلم"),
    CONNECTION_REQUESTED("طلب اتصال وارد — بانتظار موافقة المرسِل"),
    RECEIVER_REQUESTING("طلب اتصال وارد من مستلم"),
    APPROVED_TRANSFERRING("تمت الموافقة — جاري النقل الحي"),
    COMPLETED("اكتملت جلسة الإرسال"),
    EXPIRED("انتهت صلاحية الجلسة"),
    CANCELLED("تم إيقاف الجلسة")
}

enum class ReceiverConnectionPhase(val arabicLabel: String) {
    IDLE("جاهز للبحث أو المسح"),
    DISCOVERING("جاري التحقق من جلسة المرسل..."),
    CONNECTING_MANIFEST("جاري التحقق من جلسة المرسل..."),
    MANIFEST_PREVIEW("معاينة الجلسة والملفات"),
    WAITING_SENDER_APPROVAL("بانتظار موافقة المرسل..."),
    APPROVED_DOWNLOADING("تمت الموافقة • جاري التحميل"),
    APPROVED_RECEIVING("تمت الموافقة • جاري التحميل"),
    COMPLETED("اكتمل الاستلام بنجاح"),
    REJECTED("رفض المرسل طلب الاتصال"),
    EXPIRED("انتهت صلاحية جلسة المرسل"),
    CANCELLED("تم إلغاء الاستلام"),
    FAILED("تعذر الاتصال بالمرسل"),
    FAILED_UNREACHABLE("تعذر الاتصال بالمرسل")
}

enum class ConnectionApprovalStatus {
    NONE,
    PENDING,
    APPROVED,
    REJECTED,
    EXPIRED,
    CANCELLED
}

@Immutable
data class IncomingConnectionRequest(
    val requestId: String,
    val receiverDeviceName: String,
    val receiverIp: String,
    val requestedAtMillis: Long,
    val fileCount: Int,
    val totalBytes: Long
) {
    val clientDeviceName: String
        get() = receiverDeviceName

    val clientIp: String
        get() = receiverIp

    val requestedFilesCount: Int
        get() = fileCount
}

@Immutable
data class PersistedSafFolderItem(
    val uri: Uri,
    val displayName: String,
    val documentId: String,
    val isValid: Boolean = true,
    val status: SafUriStatus = SafUriStatus.VALID,
    val statusMessage: String? = null,
    val lastVerifiedMillis: Long = 0L
) {
    val treeUri: Uri
        get() = uri

    val uriString: String
        get() = uri.toString()
}

@Stable
data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val apkFile: File,
    val sizeBytes: Long,
    val lastUpdatedMillis: Long,
    val isSystemApp: Boolean,
    val hasSplitApks: Boolean = false,
    val splitCount: Int = 0,
    val iconBitmap: ImageBitmap? = null
) {
    val selectionKey: String
        get() = "app:$packageName"
}

@Stable
data class DeviceMediaItem(
    val id: String,
    val name: String,
    val uri: Uri? = null,
    val localFile: File? = null,
    val sizeBytes: Long,
    val dateModifiedMillis: Long,
    val durationMillis: Long = 0L,
    val mimeType: String? = null,
    val bucketOrFolderName: String = "",
    val relativePathInStorage: String = "",
    val category: FileCategory,
    val thumbnailBitmap: ImageBitmap? = null
) {
    val selectionKey: String
        get() = "media:$id"

    val relativePath: String
        get() = relativePathInStorage

    val fileExtensionBadge: String
        get() {
            val clean = name.substringAfterLast('/')
            if (clean.equals("index", ignoreCase = true)) return "INDEX"
            if (!clean.contains('.') || clean.endsWith('.')) return "FILE"
            val ext = clean.substringAfterLast('.', "").uppercase(Locale.ROOT)
            return if (ext.isNotBlank() && ext.length <= 8) ext else category.name.take(4)
        }

    val readableFileTypeLabel: String
        get() {
            val clean = name.substringAfterLast('/')
            val lower = clean.lowercase(Locale.ROOT)
            if (!clean.contains('.') || clean.endsWith('.')) {
                return if (lower == "index" || lower.contains("index")) "ملف فهرسة (Index)" else "ملف بدون امتداد"
            }
            return when (val ext = clean.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
                "big" -> "ملف موارد ومودات (BIG)"
                "dat" -> "ملف بيانات (DAT)"
                "tga" -> "ملف رسوميات وتكستشر (TGA)"
                "zip", "rar", "7z", "tar", "gz", "bz2" -> "ملف مضغوط (${ext.uppercase(Locale.ROOT)})"
                "idx", "index" -> "ملف فهرسة (Index)"
                "ini", "cfg", "conf", "xml", "json", "txt" -> "ملف إعدادات/نص (${ext.uppercase(Locale.ROOT)})"
                "w3d", "map", "wak", "scb", "str", "csf" -> "ملف بيانات لعبة (${ext.uppercase(Locale.ROOT)})"
                "apk", "xapk", "apks", "obb" -> "حزمة تطبيق/لعبة (${ext.uppercase(Locale.ROOT)})"
                else -> category.arabicLabel
            }
        }
}

enum class FolderStatsStatus {
    NOT_CALCULATED,
    CALCULATING,
    COMPLETED,
    PARTIALLY_READ,
    APPROXIMATE_CAPPED,
    ACCESS_RESTRICTED
}

@Immutable
data class StorageFolderItem(
    val name: String,
    val path: String,
    val relativeDisplayPath: String = name,
    val parentFolderName: String = "",
    val fileCount: Int = 0,
    val subfolderCount: Int = 0,
    val emptySubfolderCount: Int = 0,
    val unreadableCount: Int = 0,
    val totalBytes: Long = 0L,
    val lastModifiedMillis: Long = System.currentTimeMillis(),
    val mediaStoreFallbackItems: List<DeviceMediaItem> = emptyList(),
    val safTreeUri: Uri? = null,
    val safDocumentId: String? = null,
    val isProtectedSystemFolder: Boolean = false,
    val protectionReason: String? = null,
    val statsStatus: FolderStatsStatus = FolderStatsStatus.COMPLETED
) {
    val selectionKey: String
        get() = "folder:$path"

    val relativePath: String
        get() = relativeDisplayPath
}

/**
 * Represents a complete folder selected via ACTION_OPEN_DOCUMENT_TREE or local folder send,
 * tracking its hierarchy, file count, subfolder/empty-folder count, and total size as one unit.
 */
@Immutable
data class FolderBatchInfo(
    val batchId: String,
    val rootFolderName: String,
    val sourceUriOrPath: String = "",
    val totalFilesCount: Int,
    val totalSubfoldersCount: Int,
    val emptyFoldersCount: Int,
    val totalBytes: Long,
    val skippedUnreadableCount: Int = 0,
    val hasPersistentPermission: Boolean = false
)

@Immutable
data class TransferFileItem(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val category: FileCategory,
    val uri: Uri? = null,
    val localFile: File? = null,
    val packageName: String? = null,
    val hasSplitWarning: Boolean = false,
    val relativePath: String = "",
    val rootFolderName: String = "",
    val folderBatchId: String = "",
    val isDirectory: Boolean = false,
    val totalChunks: Int,
    val completedChunks: Int = 0,
    val transferredBytes: Long = 0L,
    val currentSpeedBytesPerSec: Double = 0.0,
    val status: FileTransferStatus = FileTransferStatus.QUEUED,
    val savedPath: String? = null,
    val sha256Expected: String = "",
    val sha256Actual: String = "",
    val sha256Verified: Boolean = false,
    val errorMessage: String? = null,
    val retryCount: Int = 0,
    val failureDiagnosticCode: String? = null
) {
    val progressFraction: Float
        get() = when {
            status == FileTransferStatus.COMPLETED -> 1f
            sizeBytes <= 0L -> 0f
            else -> (transferredBytes.coerceAtLeast(0L).toDouble() / sizeBytes.toDouble())
                .toFloat()
                .coerceIn(0f, 0.999f)
        }

    val progressPercent: Int
        get() = if (status == FileTransferStatus.COMPLETED) 100 else (progressFraction * 100f).toInt().coerceIn(0, 99)

    val currentSpeedMbps: Double
        get() = currentSpeedBytesPerSec / (1024.0 * 1024.0)

    val displayPathOrName: String
        get() = if (relativePath.isNotBlank()) relativePath else name

    val fileExtensionBadge: String
        get() {
            if (isDirectory || category == FileCategory.FOLDER) return "DIR"
            val clean = name.substringAfterLast('/')
            if (!clean.contains('.') || clean.endsWith('.')) return "FILE"
            val ext = clean.substringAfterLast('.', "").uppercase(Locale.ROOT)
            return if (ext.isNotBlank() && ext.length <= 8) ext else category.name.take(4)
        }
}

data class TransferHistoryRecord(
    val id: String,
    val fileName: String,
    val sizeBytes: Long,
    val category: FileCategory,
    val direction: TransferDirection,
    val status: FileTransferStatus,
    val timestampMillis: Long,
    val savedPath: String? = null,
    val sha256Hash: String = "",
    val sha256Verified: Boolean = false,
    val averageSpeedBytesPerSec: Double = 0.0,
    val peerAddress: String = "",
    val errorMessage: String? = null,
    val relativePath: String = "",
    val rootFolderName: String = "",
    val uriString: String? = null,
    val mimeType: String? = null
) {
    val isCompleted: Boolean
        get() = status == FileTransferStatus.COMPLETED && !(savedPath ?: "").endsWith(".part")

    val isVideoFile: Boolean
        get() {
            if (category == FileCategory.VIDEO) return true
            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return ext in setOf("mp4", "mkv", "webm", "mov", "avi", "3gp", "flv", "m4v", "ts")
        }

    val isImageFile: Boolean
        get() {
            if (category == FileCategory.IMAGE) return true
            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
        }

    fun resolveExistingFile(): File? {
        val path = savedPath?.trim().orEmpty()
        if (path.isBlank() || path.startsWith("content://") || path.endsWith(".part")) return null
        val f = File(path)
        return if (f.exists() && f.isFile && f.length() > 0L) f else null
    }
}

data class DiscoveredPeerSession(
    val sessionCode: String,
    val hostIp: String,
    val port: Int,
    val deviceName: String,
    val fileCount: Int,
    val totalBytes: Long,
    val lastSeenMillis: Long
)

data class HotspotNetworkStatus(
    val localIp: String = "192.168.43.1",
    val allLocalIps: List<String> = listOf("192.168.43.1"),
    val port: Int = 8989,
    val is5GHzBand: Boolean = false,
    val frequencyMHz: Int = 2412,
    val linkSpeedMbps: Int = 144,
    val ssidOrInterface: String = "شبكة محلية متاحة",
    val networkTypeLabel: String = "Wi-Fi / نقطة اتصال محلية",
    val isServerRunning: Boolean = false
) {
    val webPortalUrl: String
        get() = "http://$localIp:$port"
}

data class ReceivedApkItem(
    val id: String,
    val fileName: String,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long = 1L,
    val sizeBytes: Long,
    val lastModifiedMillis: Long,
    val file: File,
    val iconBitmap: ImageBitmap? = null,
    val isValidApk: Boolean = true,
    val isSplitApk: Boolean = false,
    val minSdkVersion: Int = 21,
    val targetSdkVersion: Int = 34,
    val installStatusLabel: String = "جاهز للتثبيت",
    val sha256Verified: Boolean = true
) {
    val filePath: String
        get() = file.absolutePath

    val isValidArchive: Boolean
        get() = isValidApk

    val statusMessage: String
        get() = installStatusLabel
}

enum class TransportMode(
    val arabicTitle: String,
    val arabicDescription: String
) {
    AUTO_SMART(
        arabicTitle = "ذكي تلقائي (Wi-Fi + بلوتوث للاقتران)",
        arabicDescription = "يستخدم البلوتوث لاكتشاف الجهاز والاقتران وتبادل الجلسة، ثم ينقل البيانات عبر Wi-Fi / نقطة الاتصال بأقصى سرعة (ويستخدم البلوتوث للملفات الصغيرة عند تعذر الشبكة)"
    ),
    WIFI_HOTSPOT(
        arabicTitle = "واي فاي / نقطة اتصال (أقصى سرعة)",
        arabicDescription = "نقل مباشر عالي السرعة عبر الشبكة المحلية أو نقطة الاتصال (مثالي للفيديوهات الضخمة حتى 40 GB والمجلدات)"
    ),
    BLUETOOTH_DIRECT(
        arabicTitle = "بلوتوث مباشر (Bluetooth Classic)",
        arabicDescription = "نقل البيانات مباشرة عبر مقبس البلوتوث RFCOMM بدون Wi-Fi (مناسب للملفات الصغيرة؛ أبطأ من Wi-Fi في الملفات الكبيرة)"
    );

    val arabicSubtitle: String
        get() = arabicDescription
}

enum class BluetoothState(val arabicLabel: String) {
    UNSUPPORTED("البلوتوث غير مدعوم على هذا الجهاز"),
    PERMISSION_REQUIRED("يتطلب صلاحية البلوتوث للأجهزة القريبة"),
    DISABLED("البلوتوث مغلق — اضغط لتفعيله"),
    READY("البلوتوث جاهز للبحث والاقتران"),
    SCANNING("جاري البحث عن أجهزة البلوتوث القريبة..."),
    LISTENING("جاهز لاستقبال اتصال بلوتوث من المستلم..."),
    CONNECTING("جاري الاتصال عبر البلوتوث..."),
    CONNECTED("متصل عبر البلوتوث"),
    TRANSFERRING("جاري نقل الملفات عبر البلوتوث..."),
    DISCONNECTED("انقطع اتصال البلوتوث"),
    ERROR("تعذر الاتصال عبر البلوتوث")
}

data class BluetoothPeerDevice(
    val name: String,
    val address: String,
    val isPaired: Boolean,
    val rssi: Int = 0,
    val lastSeenMillis: Long = System.currentTimeMillis()
) {
    val displayName: String
        get() = if (name.isNotBlank()) name else "جهاز بلوتوث ($address)"
}

enum class AppScreen(val arabicTabTitle: String) {
    HOME("الرئيسية"),
    APPS("التطبيقات"),
    RECEIVED_APKS("التطبيقات المستلمة"),
    IMAGES("الصور"),
    VIDEOS("الفيديوهات"),
    AUDIO("الصوتيات"),
    FILES("الملفات"),
    SEND("إرسال"),
    RECEIVE("استلام"),
    HISTORY("سجل النقل"),
    QR_SCANNER("مسح QR"),
    LIVE_TRANSFER("النقل الحي"),
    WEBRTC_PORTAL("بوابة الويب")
}

